﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Schedule;

namespace ScheduleTest
{
    [TestClass]
    public class ScheduleTestFun
    {
        [TestMethod]
        public void Fun1()
        {
            int x = -3;
            int expected = 0;

            Function c = new Function();
            double actual = c.f1(x);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Fun1Double()
        {
            double x = -3.5;
            double expected = -0.5;

            Function c = new Function();
            double actual = c.f1(x);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Fun1Error()
        {
            int x = 3;
            string expected = "x не входит в данный промежуток";

            Function c = new Function();
            double actual = c.f1(x);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Fun2()
        {
            int x = -1;
            double expected = 0.5;

            Function c = new Function();
            double actual = c.f2(x);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Fun2Double()
        {
            double x = -1.5;
            double expected = 0.75;

            Function c = new Function();
            double actual = c.f2(x);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Fun2Error()
        {
            int x = 5;
            string expected = "x не входит в данный промежуток";

            Function c = new Function();
            double actual = c.f2(x);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Fun3()
        {
            int x = 5;
            int expected = -2;

            Function c = new Function();
            double actual = c.f3(x);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Fun3Double()
        {
            double x = 5.7;
            int expected = -2;

            Function c = new Function();
            double actual = c.f3(x);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Fun3Error()
        {
            int x = 1;
            string expected = "x не входит в данный промежуток";

            Function c = new Function();
            double actual = c.f3(x);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Fun4()
        {
            int x = 1;
            int r = 5;
            double expected = 4.899;

            Function c = new Function();
            double actual = c.f4(x, r);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Fun4Double()
        {
            double x = 1.6;
            double r = 2.4;
            double expected = 1.789;

            Function c = new Function();
            double actual = c.f4(x,r);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Fun4Error()
        {
            int x = -2;
            int r = 1;
            string expected = "x не входит в данный промежуток";

            Function c = new Function();
            double actual = c.f4(x,r);

            Assert.AreEqual(expected, actual);
        }
    }
}
